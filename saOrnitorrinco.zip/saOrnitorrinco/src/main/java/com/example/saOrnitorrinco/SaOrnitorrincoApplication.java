package com.example.saOrnitorrinco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SaOrnitorrincoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaOrnitorrincoApplication.class, args);
	}

}
