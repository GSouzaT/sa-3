package com.example.saOrnitorrinco.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.saOrnitorrinco.model.Mesa;
import com.example.saOrnitorrinco.repository.MesaRepository;
import com.example.saOrnitorrinco.service.MesaService;

@RestController
@RequestMapping("/mesas")
public class MesaController {
	@Autowired
	private MesaRepository mesaRepository;
	
	@Autowired
	private MesaService mesaService;
	
	@PutMapping(path = "/{id}")
	public ResponseEntity<> estaDisponivel(@RequestBody List<Mesa> mesas, @PathVariable Integer id) {
		try {
			mesaService.estaDisponivel(true);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (IllegalArgumentException e) {
			return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}
}
