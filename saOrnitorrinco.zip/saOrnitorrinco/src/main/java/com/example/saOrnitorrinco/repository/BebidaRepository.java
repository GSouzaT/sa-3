package com.example.saOrnitorrinco.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.saOrnitorrinco.model.Bebida;

public interface BebidaRepository extends JpaRepository<Bebida, Integer>{
	
	
}
