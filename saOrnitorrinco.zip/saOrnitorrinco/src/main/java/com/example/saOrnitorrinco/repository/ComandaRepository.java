package com.example.saOrnitorrinco.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.saOrnitorrinco.model.Comanda;

public interface ComandaRepository extends JpaRepository<Comanda, Integer> {

}
