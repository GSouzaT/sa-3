package com.example.saOrnitorrinco.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.saOrnitorrinco.model.Prato;

public interface PratoRepository extends JpaRepository<Prato, Integer>{

	
}
