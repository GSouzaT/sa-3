package com.example.saOrnitorrinco.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.saOrnitorrinco.model.Bebida;
import com.example.saOrnitorrinco.repository.BebidaRepository;

@Service
public class BebidaService {
	@Autowired
	private BebidaRepository bebidaRepository;
	
	public Bebida cadastrarBebida(String nome, double preco, boolean temAlcool, double teorAlcoolico) {
		Bebida bebida = new Bebida(nome, preco, temAlcool, teorAlcoolico);
		return bebidaRepository.save(bebida);
	}
	
	public void deletarBebida(Integer id) {
		
	}
	
	public List<Bebida> getBebida() {
		return bebidaRepository.findAll();
	}
	
	public Bebida getBebida(Integer id) {
		return bebidaRepository.findById(id).get();
	}
	
}
