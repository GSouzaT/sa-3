package com.example.saOrnitorrinco.teste;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.saOrnitorrinco.model.Bebida;
import com.example.saOrnitorrinco.repository.BebidaRepository;
import com.example.saOrnitorrinco.service.BebidaService;

@ExtendWith(SpringExtension.class)
public class TesteBebida {
	@Mock
	BebidaRepository bRepo;
	
	@InjectMocks
	BebidaService bServ;
	
	@Test
	void testCreateBebida() {
		Bebida bebida = new Bebida("Vodka", 15.00, true, 39.00);
		
		when(bRepo.save(any(Bebida.class))).thenReturn(bebida);
		
		Bebida beb = this.bServ.cadastrarBebida("Vodka", 15.00, true, 39.00);
		
		assertNotNull(beb);
		assertEquals(bebida.getTeorAlcoolico(), beb.getTeorAlcoolico());
		assertEquals(bebida.getPreco(), beb.getPreco());
		assertEquals(bebida.getNome(), beb.getNome());
		assertEquals(bebida.isTemAlcool(), beb.isTemAlcool());
		
		
	}
	
}
