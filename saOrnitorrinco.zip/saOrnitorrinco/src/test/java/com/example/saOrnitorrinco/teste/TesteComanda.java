package com.example.saOrnitorrinco.teste;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.saOrnitorrinco.model.Cliente;
import com.example.saOrnitorrinco.model.Comanda;
import com.example.saOrnitorrinco.model.Mesa;
import com.example.saOrnitorrinco.repository.ComandaRepository;
import com.example.saOrnitorrinco.service.ComandaService;

@ExtendWith(SpringExtension.class)
public class TesteComanda {

	@Mock
	ComandaRepository cRepo;
	
	@InjectMocks
	ComandaService cServ;
	
	@Test
	void testCreateComanda() {
		
		Cliente cli = new Cliente();
		
		Mesa mesa = new Mesa();
		
		Comanda comanda = new Comanda(null, null, cli, mesa);
		
		when(cRepo.save(any(Comanda.class))).thenReturn(comanda);
		
		Comanda com = this.cServ.cadastrarComanda(null, null, cli, mesa);
		
		assertNotNull(com);
		assertEquals(comanda.getCliente(), com.getCliente());
		assertEquals(comanda.getMesa(), com.getMesa());		
		
	}
	
}
