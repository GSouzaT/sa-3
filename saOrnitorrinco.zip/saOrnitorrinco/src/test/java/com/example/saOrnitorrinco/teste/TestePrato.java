package com.example.saOrnitorrinco.teste;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.saOrnitorrinco.model.Prato;
import com.example.saOrnitorrinco.repository.PratoRepository;
import com.example.saOrnitorrinco.service.PratoService;

@ExtendWith(SpringExtension.class)
public class TestePrato {

	@Mock
	PratoRepository pRepo;
	
	@InjectMocks
	PratoService pServ;
	
	@Test
	void testCreatePrato() {
		Prato prato = new Prato("hamburguer", 12.50, "pão e carne");
		
		when(pRepo.save(any(Prato.class))).thenReturn(prato);
		
		Prato prat = this.pServ.cadastrarPrato("hamburguer", 12.50, "pão e carne");
		
		assertNotNull(prat);
		assertEquals(prato.getDescricao(), prat.getDescricao());
		assertEquals(prato.getPreco(), prat.getPreco());
		assertEquals(prato.getNome(), prat.getNome());
	}
}
